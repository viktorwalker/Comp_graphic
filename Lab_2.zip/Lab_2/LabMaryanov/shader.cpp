#include "shader.h"

char* readShaderSrc(const char* filePath) {
    FILE* file;
    if (fopen_s(&file, filePath, "r") != 0) {
        fprintf(stderr, "Error: could not open shader file %s\n", filePath);
        return nullptr;
    }

    fseek(file, 0, SEEK_END);
    long length = ftell(file);
    rewind(file);

    char* src = (char*)malloc(length + 1);
    if (!src) {
        fprintf(stderr, "Error: memory allocation failed for shader source\n");
        fclose(file);
        return nullptr;
    }

    fread(src, 1, length, file);
    src[length] = '\0';
    fclose(file);
    return src;
}

GLuint compShader(GLenum shadType, const char* src) {
    GLuint shader = glCreateShader(shadType);
    glShaderSource(shader, 1, &src, nullptr);
    glCompileShader(shader);

    GLint success;
    glGetShaderiv(shader, GL_COMPILE_STATUS, &success);
    if (!success) {
        char infoLog[512];
        glGetShaderInfoLog(shader, 512, nullptr, infoLog);
        fprintf(stderr, "Error: shader compilation failed\n%s\n", infoLog);
    }

    return shader;
}

GLuint createShader(const char* vertex, const char* fragment, GLint* time_location) {
    char* vertSrc = readShaderSrc(vertex);
    char* fragSrc = readShaderSrc(fragment);

    if (!vertSrc || !fragSrc) {
        fprintf(stderr, "Error: could not load shader source files\n");
        free(vertSrc);
        free(fragSrc);
        return 0;
    }

    GLuint vertShader = compShader(GL_VERTEX_SHADER, vertSrc);
    GLuint fragShader = compShader(GL_FRAGMENT_SHADER, fragSrc);

    GLuint program = glCreateProgram();
    glAttachShader(program, vertShader);
    glAttachShader(program, fragShader);
    glLinkProgram(program);

    GLint success;
    glGetProgramiv(program, GL_LINK_STATUS, &success);
    if (!success) {
        char infoLog[512];
        glGetProgramInfoLog(program, 512, nullptr, infoLog);
        fprintf(stderr, "Error: program linking failed\n%s\n", infoLog);
    }

    *time_location = glGetUniformLocation(program, "time");

    glDeleteShader(vertShader);
    glDeleteShader(fragShader);
    free(vertSrc);
    free(fragSrc);

    return program;
}

void setUniform(GLuint prog, const char* name, float r, float g, float b, float a) {
    GLint location = glGetUniformLocation(prog, name);
    if (location == -1) {
        fprintf(stderr, "Warning: uniform '%s' not found or unused.\n", name);
    }
    glUniform4f(location, r, g, b, a);
}
