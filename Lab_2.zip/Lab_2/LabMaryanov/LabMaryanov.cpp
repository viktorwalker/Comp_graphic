﻿#define GLEW_DLL
#define GLFW_DLL

#include "GL/glew.h"
#include "GLFW/glfw3.h"
#include <cstdio>
#include <cmath>

#include "shader.h"

GLfloat square[] = {
    -0.5f, -0.5f, 0.0f,
     0.5f, -0.5f, 0.0f,
     0.5f,  0.5f, 0.0f,
    -0.5f,  0.5f, 0.0f
};

GLuint indices[] = {
    0, 1, 2,
    2, 3, 0
};

int main()
{
    printf("10 VAR.\n");

    if (!glfwInit()) {
        fprintf(stderr, "ERROR\n");
        return 1;
    }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 6);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);

    GLFWwindow* windo = glfwCreateWindow(512, 512, "Square", NULL, NULL);
    if (!windo) {
        fprintf(stderr, "ERROR creating window\n");
        glfwTerminate();
        return 1;
    }

    glfwMakeContextCurrent(windo);
    glewExperimental = GL_TRUE;
    glewInit();

    GLuint VAO, VBO, EBO;
    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    glGenBuffers(1, &EBO);

    glBindVertexArray(VAO);

    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(square), square, GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    GLint dummyTimeLocation;
    GLuint shader_program = createShader("vertshader.glsl", "fragshader.glsl", &dummyTimeLocation);

    while (!glfwWindowShouldClose(windo)) {
        glClearColor(0.2, 1.0, 1.0, 1);
        glClear(GL_COLOR_BUFFER_BIT);

        float t = glfwGetTime();
        float red = (sin(t) + 1.0f) / 2.0f;
        float green = (cos(t) + 1.0f) / 2.0f;
        float blue = (sin(t * 0.5f) + 1.0f) / 2.0f;

        glUseProgram(shader_program);
        setUniform(shader_program, "ourColour", red, green, blue, 1.0f);

        glBindVertexArray(VAO);
        glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);

        glfwSwapBuffers(windo);
        glfwPollEvents();
    }

    glfwTerminate();
    return 0;
}
