﻿#define GLEW_DLL
#define GLFW_DLL

#include "GL/glew.h" 
#include "GLFW/glfw3.h" 
#include <cstdio>

int main()
{
    printf("10 VAR.\n");

    if (!glfwInit()) {
        fprintf(stderr, "ERROR\n");
        return 1;
    }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 1);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);

    GLFWwindow* windo;
    windo = glfwCreateWindow(512, 512, "Square", NULL, NULL);

    if (!windo) {
        fprintf(stderr, "ERROR\n");
        glfwTerminate();
        return 1;
    }

    glfwMakeContextCurrent(windo);

    glewExperimental = GL_TRUE;
    glewInit();

    while (!glfwWindowShouldClose(windo))
    {
        glClearColor(0.2, 1.0, 1.0, 1); 
        glClear(GL_COLOR_BUFFER_BIT);

        glColor3f(1.0, 0.8, 0.5); 
        glBegin(GL_QUADS);
        glVertex2f(-0.5f, -0.5f); 
        glVertex2f(0.5f, -0.5f);  
        glVertex2f(0.5f, 0.5f);   
        glVertex2f(-0.5f, 0.5f);  
        glEnd();

        glfwSwapBuffers(windo);
        glfwPollEvents();
    }

    glfwTerminate();
    return 0;
}
